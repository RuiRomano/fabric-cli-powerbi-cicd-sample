from argparse import Namespace
from typing import Any

import jwt

from fabric_cli.core import fab_constant, fab_logger, fab_state_config
from fabric_cli.core.fab_auth import FabAuth
from fabric_cli.core.fab_context import Context
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui


def init(args: Namespace) -> Any:
    auth_options = [
        "Interactive with a web browser",
        "Service principal authentication",
    ]

    utils_mem_store.clear_caches()

    if any([args.username, args.password]):
        if not all([args.username, args.tenant, args.password]):
            raise FabricCLIError(
                "-u/--username, -p/--password and -t/--tenant all must be provided",
                fab_constant.ERROR_INVALID_INPUT,
            )
        else:
            FabAuth().set_access_mode("service_principal")
            FabAuth().set_tenant(args.tenant)
            FabAuth().set_spn(args.username, args.password)
            FabAuth().get_access_token(scope=fab_constant.SCOPE_FABRIC_DEFAULT)
            FabAuth().get_access_token(scope=fab_constant.SCOPE_ONELAKE_DEFAULT)
            FabAuth().get_access_token(scope=fab_constant.SCOPE_AZURE_DEFAULT)
            Context().set_context(FabAuth().get_tenant())
            fab_state_config.init_defaults()
    else:
        selected_auth = utils_ui.prompt_select_item(
            "How would you like to authenticate Fabric CLI?", auth_options
        )

        try:
            if selected_auth == "Interactive with a web browser":
                if getattr(args, "tenant", None) is not None:
                    FabAuth().set_tenant(args.tenant)
                FabAuth().set_access_mode("user")
                FabAuth().get_access_token(scope=fab_constant.SCOPE_FABRIC_DEFAULT)
                FabAuth().get_access_token(scope=fab_constant.SCOPE_ONELAKE_DEFAULT)
                FabAuth().get_access_token(scope=fab_constant.SCOPE_AZURE_DEFAULT)
                Context().set_context(FabAuth().get_tenant())
                fab_state_config.init_defaults()
            elif selected_auth == "Service principal authentication":
                fab_logger.log_warning(
                    "Ensure tenant setting is enabled for Service Principal auth"
                )

                client_id = utils_ui.prompt_ask("Enter client ID:")
                if not client_id:
                    return

                client_secret = utils_ui.prompt_password("Enter client secret:")
                if not client_secret:
                    return

                tenant_id = utils_ui.prompt_ask("Enter tenant ID:")
                if not tenant_id:
                    return

                FabAuth().set_access_mode("service_principal")
                FabAuth().set_tenant(tenant_id)
                FabAuth().set_spn(client_id, client_secret)
                FabAuth().get_access_token(scope=fab_constant.SCOPE_FABRIC_DEFAULT)
                FabAuth().get_access_token(scope=fab_constant.SCOPE_ONELAKE_DEFAULT)
                FabAuth().get_access_token(scope=fab_constant.SCOPE_AZURE_DEFAULT)
                Context().set_context(FabAuth().get_tenant())
                fab_state_config.init_defaults()

        except KeyboardInterrupt:
            return False
        return True


def logout(args: Namespace) -> None:
    FabAuth().logout()

    # Clear cache and context
    utils_mem_store.clear_caches()
    Context().reset_context()

    utils_ui.print_done("Logged out of Fabric account")


def status(args: Namespace) -> None:
    auth = FabAuth()
    tenant_id = auth.get_tenant_id()

    def __get_token_info(scope):
        token = auth.get_access_token(scope, interactive_renew=False)
        if isinstance(token, str):
            token = token.encode()  # Ensure bytes type
        return _get_token_info_from_bearer_token(token) if token else {}

    token_info = __get_token_info(fab_constant.SCOPE_FABRIC_DEFAULT)

    upn = token_info.get("upn") or "N/A"
    oid = token_info.get("oid") or "N/A"

    def __mask_token(scope):
        token = auth.get_access_token(scope, interactive_renew=False)
        if isinstance(token, str):
            token = token.encode()  # Ensure bytes type
        return (
            token[:4].decode() + "************************************"
            if token
            else "N/A"
        )

    fabric_secret = __mask_token(fab_constant.SCOPE_FABRIC_DEFAULT)
    storage_secret = __mask_token(fab_constant.SCOPE_ONELAKE_DEFAULT)
    azure_secret = __mask_token(fab_constant.SCOPE_AZURE_DEFAULT)

    # Check login status
    login_status = (
        "✓ Logged in to app.fabric.microsoft.com"
        if fabric_secret != "N/A"
        else "✗ Not logged in to app.fabric.microsoft.com"
    )

    utils_ui.print_grey(
        f"""{login_status}
  - Account: {upn} ({oid})
  - Tenant ID: {tenant_id}
  - Token (fabric/powerbi): {fabric_secret}
  - Token (storage): {storage_secret}
  - Token (azure): {azure_secret}"""
    )


# Utils
def _get_token_info_from_bearer_token(bearer_token: str) -> dict[str, str]:
    payload = jwt.decode(bearer_token, options={"verify_signature": False})

    # https://learn.microsoft.com/en-us/entra/identity-platform/access-token-claims-reference
    upn = payload.get("upn")
    oid = payload.get("oid")

    return {"upn": upn, "oid": oid}
