import json

from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.core.fab_hiearchy import Item, OneLakeItem
from fabric_cli.utils import fab_cmd_ls_utils as utils_ls
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils


def list_item_folders(item: Item, args):
    show_details = bool(args.long)

    args.directory = item.get_path_id().strip("/")
    response = onelake_api.list_tables_files(args)

    if response.status_code in (200, 201):
        response_data = json.loads(response.text)
        paths = response_data.get("paths", [])

        for entry in paths:
            entry["name"] = (
                entry["name"].split(
                    "/")[1] if "/" in entry["name"] else entry["name"]
            )

        columns = ["permissions", "lastModified",
                   "name"] if show_details else ["name"]
        utils_ui.print_entries_unix_style(paths, columns, header=show_details)
    return None


# Onelake - SubFolder, Shortcut, File
def list_onelake(onelake: OneLakeItem, args):
    show_details = bool(args.long)

    local_path = utils.remove_dot_suffix(onelake.get_local_path())
    workspace_id = onelake.get_workspace_id()
    item_id = onelake.get_item_id()

    args.directory = f"{workspace_id}/?recursive=false&resource=filesystem&directory={item_id}/{local_path}&getShortcutMetadata=true"
    response = onelake_api.list_tables_files_recursive(args)

    if response.status_code in {200, 201}:
        if response.text:
            response_data = json.loads(response.text)
            paths = response_data.get("paths", [])

            if paths:
                for entry in paths:
                    utils_ls.update_entry_name_and_type(entry, local_path)

                columns = (
                    ["permissions", "lastModified", "name", "type"]
                    if show_details
                    else ["name"]
                )
                utils_ui.print_entries_unix_style(
                    paths, columns, header=show_details)
            else:
                utils_ui.print_grey("[]")
