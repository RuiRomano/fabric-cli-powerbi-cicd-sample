import json
import os
from argparse import Namespace
from typing import Optional

from fabric_cli.client import fab_api_capacity as capacity_api
from fabric_cli.client import fab_api_connection as connection_api
from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_gateway as gateway_api
from fabric_cli.client import fab_api_item as item_api
from fabric_cli.client import fab_api_jobs as jobs_api
from fabric_cli.client import (
    fab_api_managedprivateendpoint as managed_private_endpoint_api,
)
from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.client import fab_api_shortcuts as shortcut_api
from fabric_cli.client import fab_api_sparkpool as sparkpool_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.commands.fs import fab_fs as fs
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    OneLakeItem,
    VirtualItem,
    VirtualWorkspaceItem,
    Workspace,
)
from fabric_cli.core.fab_types import (
    ItemType,
    OneLakeItemType,
    VirtualItemType,
    VirtualWorkspaceItemType,
)
from fabric_cli.utils import fab_cmd_get_utils as utils_get
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_util as utils


def exec_command(args: Namespace, context: FabricElement) -> None:
    args.output = utils.process_nargs(args.output)
    args.query = utils.process_nargs(args.query)

    if isinstance(context, Workspace):
        _get_workspace(context, args)
    elif isinstance(context, VirtualWorkspaceItem):
        _get_virtual_ws_item(context, args)
    elif isinstance(context, Item):
        _get_item(context, args)
    elif isinstance(context, VirtualItem):
        _get_virtual_item(context, args)
    elif isinstance(context, OneLakeItem):
        if context.get_nested_type() == OneLakeItemType.SHORTCUT:
            _get_shortcut(context, args)
        else:
            _get_onelake_resource(context, args)


# Workspaces
def _get_workspace(
    workspace: Workspace, args: Namespace, debug: Optional[bool] = True
) -> dict:
    args.ws_id = workspace.get_id()

    workspace_def = {}
    response = workspace_api.get_workspace(args)

    if response.status_code == 200:
        workspace_def = json.loads(response.text)

        # Add managed private endpoints
        try:
            managed_private_endpoints = (
                workspace_api.ls_workspace_managed_private_endpoints(args)
            )
            if managed_private_endpoints.status_code == 200:
                managed_private_endpoints_def = json.loads(
                    managed_private_endpoints.text
                )
                workspace_def["managedPrivateEndpoints"] = (
                    managed_private_endpoints_def["value"]
                )
        except Exception as e:
            pass

        # Add Spark settings
        try:
            spark_settings = workspace_api.get_workspace_spark_settings(args)
            if spark_settings.status_code == 200:
                spark_settings_def = json.loads(spark_settings.text)
                workspace_def["sparkSettings"] = spark_settings_def
        except Exception as e:
            pass

        # Add role assignments
        try:
            acls = workspace_api.acl_list_from_workspace(args)
            if acls.status_code == 200:
                acls_def = json.loads(acls.text)
                workspace_def["roleAssignments"] = acls_def["value"]
        except Exception as e:
            pass

        utils_get.query_and_export(
            workspace_def, args, workspace.get_full_name(), debug
        )

    return workspace_def


# Virtual Workspace Items
def _get_virtual_ws_item(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace
) -> None:
    match virtual_ws_item.get_item_type():
        case VirtualWorkspaceItemType.CAPACITY:
            _get_capacity(virtual_ws_item, args)
        case VirtualWorkspaceItemType.DOMAIN:
            _get_domain(virtual_ws_item, args)
        case VirtualWorkspaceItemType.CONNECTION:
            _get_connection(virtual_ws_item, args)
        case VirtualWorkspaceItemType.GATEWAY:
            _get_gateway(virtual_ws_item, args)
        case _:
            raise FabricCLIError("Not supported")


# Virtual Workspace Items - Capacity
def _get_capacity(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    fs._check_fabric_capacity(virtual_ws_item)
    fs.fill_capacity_args(virtual_ws_item, args)

    virtual_ws_item_def = {}
    response = capacity_api.get_capacity(args)
    if response.status_code == 200:
        virtual_ws_item_def = json.loads(response.text)
        virtual_ws_item_def["fabricId"] = virtual_ws_item.get_id()
        utils_get.query_and_export(
            virtual_ws_item_def, args, virtual_ws_item.get_name(), debug
        )

    return virtual_ws_item_def


# Virtual Workspace Items - Connection
def _get_connection(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    args.id = virtual_ws_item.get_id()

    virtual_ws_item_def = {}
    response = connection_api.get_connection(args)
    if response.status_code == 200:
        virtual_ws_item_def = json.loads(response.text)
        utils_get.query_and_export(
            virtual_ws_item_def, args, virtual_ws_item.get_name(), debug
        )

    return virtual_ws_item_def


# Virtual Workspace Items - Domain
def _get_domain(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    args.name = virtual_ws_item.get_short_name()
    args.id = virtual_ws_item.get_id()

    virtual_ws_item_def = {}
    response = domain_api.get_domain(args)
    if response.status_code == 200:
        virtual_ws_item_def = json.loads(response.text)

        # Add workspaces
        try:
            response = domain_api.list_domain_workspaces(args)
            if response.status_code == 200:
                _assigned_workspaces: list = json.loads(response.text)["value"]
                virtual_ws_item_def["domainWorkspaces"] = _assigned_workspaces
        except Exception as e:
            pass

        utils_get.query_and_export(
            virtual_ws_item_def, args, virtual_ws_item.get_name(), debug
        )

    return virtual_ws_item_def


# Virtual Workspace Items - Gateway
def _get_gateway(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    args.id = virtual_ws_item.get_id()

    virtual_ws_item_def = {}
    response = gateway_api.get_gateway(args)
    if response.status_code == 200:
        virtual_ws_item_def = json.loads(response.text)
        utils_get.query_and_export(
            virtual_ws_item_def, args, virtual_ws_item.get_name(), debug
        )

    return virtual_ws_item_def


# Items
def _get_item(
    item: Item,
    args: Namespace,
    debug: Optional[bool] = True,
    decode: Optional[bool] = True,
) -> dict:
    # If no payload query, no need to obtain definition
    obtain_definition = True
    if args.query and args.query in fab_constant.ITEM_METADATA_PROPERTIES:
        obtain_definition = False

    item_def = utils.get_item_with_definition(item, args, decode, obtain_definition)

    # Connections
    try:
        args.ws_id = item.get_workspace_id()
        args.id = item.get_id()
        connections = item_api.get_item_connections(args)

        connections_def = json.loads(connections.text)
        item_def["connections"] = connections_def["value"]
    except Exception as e:
        pass

    # Schedules
    try:
        args.item_id = item.get_id()
        args.jobType = item.get_job_type().value

        if args.jobType is not None:
            schedules = jobs_api.list_item_schedules(args)

            if schedules.status_code == 200:
                schedules_def = json.loads(schedules.text)
                item_def["schedules"] = schedules_def["value"]
    except Exception as e:
        pass

    # Environment
    if item.get_item_type() == ItemType.ENVIRONMENT:
        try:
            item_def = utils_get.get_environment_metadata(item_def, args)
        except Exception as e:
            pass

    # Mirrored Database
    if item.get_item_type() == ItemType.MIRRORED_DATABASE:
        try:
            item_def = utils_get.get_mirroreddb_metadata(item_def, args)
        except Exception as e:
            pass

    utils_get.query_and_export(item_def, args, item.get_full_name(), debug)

    return item_def


# Virtual Items
def _get_virtual_item(virtual_item: VirtualItem, args: Namespace) -> None:
    match virtual_item.get_item_type():
        case VirtualItemType.SPARK_POOL:
            _get_spark_pool(virtual_item, args)
        case VirtualItemType.MANAGED_PRIVATE_ENDPOINT:
            _get_managed_private_endpoint(virtual_item, args)
        case VirtualItemType.EXTERNAL_DATA_SHARE:
            _get_external_data_share(virtual_item, args)
        case _:
            raise FabricCLIError("Not supported")


# Virtual Items - Spark Pool
def _get_spark_pool(
    virtual_item: VirtualItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    args.ws_id = virtual_item.get_workspace_id()
    args.id = virtual_item.get_id()

    virtual_item_def = {}
    response = sparkpool_api.get_spark_pool(args)
    if response.status_code == 200:
        virtual_item_def = json.loads(response.text)
        utils_get.query_and_export(
            virtual_item_def, args, virtual_item.get_name(), debug
        )

    return virtual_item_def


# Virtual Items - Managed Private Endpoint
def _get_managed_private_endpoint(
    virtual_item: VirtualItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    args.ws_id = virtual_item.get_workspace_id()
    args.id = virtual_item.get_id()

    virtual_item_def = {}
    response = managed_private_endpoint_api.get_managed_private_endpoint(args)
    if response.status_code == 200:
        virtual_item_def = json.loads(response.text)
        utils_get.query_and_export(
            virtual_item_def, args, virtual_item.get_name(), debug
        )

    return virtual_item_def


# Virtual Items - External Data Share
def _get_external_data_share(
    virtual_item: VirtualItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    item_name = utils.get_item_name_from_eds_name(virtual_item.get_name())
    args.item_id = utils_mem_store.get_item_id(virtual_item.get_workspace(), item_name)

    args.ws_id = virtual_item.get_workspace_id()
    args.id = virtual_item.get_id()
    response = item_api.get_item_external_data_share(args)

    virtual_item_def = {}
    if response.status_code == 200:
        virtual_item_def = json.loads(response.text)
        utils_get.query_and_export(
            virtual_item_def, args, virtual_item.get_name(), debug
        )

    return virtual_item_def


# OneLake - File and Folder
def _get_onelake_resource(
    context: OneLakeItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    third_part = context.get_local_path()
    workspace_id = context.get_workspace_id()
    item_id = context.get_item_id()

    args.directory = f"{workspace_id}/?recursive=false&resource=filesystem&directory={item_id}/{third_part}&getShortcutMetadata=true"
    response = onelake_api.list_tables_files_recursive(args)

    onelake_def = json.loads(response.text)
    onelake_def.pop("ContinuationToken", None)
    utils_get.query_and_export(onelake_def, args, third_part, debug)

    return onelake_def


# OneLake - Shortcut
def _get_shortcut(
    shortcut: OneLakeItem, args: Namespace, debug: Optional[bool] = True
) -> dict:
    args.ws_id = shortcut.get_workspace_id()
    args.id = shortcut.get_item_id()
    args.path, name = os.path.split(shortcut.get_local_path().rstrip("/"))

    # Remove .Shortcut extension
    args.name = utils.remove_dot_suffix(name)

    # Obtain shortcut metadata
    response = shortcut_api.get_shortcut(args)

    shortcut_def = json.loads(response.text)
    utils_get.query_and_export(shortcut_def, args, shortcut.get_full_name(), debug)

    return shortcut_def
