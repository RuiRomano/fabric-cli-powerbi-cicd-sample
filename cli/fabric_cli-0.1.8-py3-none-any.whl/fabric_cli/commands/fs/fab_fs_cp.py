import os
from argparse import Namespace

from fabric_cli.commands.fs import fab_fs_mv as fs_mv
from fabric_cli.core import fab_constant
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    LocalPath,
    OneLakeItem,
    Workspace,
)
from fabric_cli.core.fab_types import OneLakeItemType
from fabric_cli.utils import fab_cmd_cp_utils as cp_utils
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils


def exec_command(
    args: Namespace, from_context: FabricElement, to_context: FabricElement
) -> None:
    args.from_path, args.to_path = from_context.get_path(), to_context.get_path()

    # Workspaces
    if isinstance(from_context, Workspace) and isinstance(to_context, Workspace):
        fs_mv._move_workspace_items_if_types_match(
            from_context, to_context, args, delete_from_item=False
        )

    # Items
    elif isinstance(from_context, Item) and isinstance(to_context, Item):
        fs_mv._move_item_if_types_match(
            from_context, to_context, args, delete_from_item=False
        )

    # OneLake to OneLake
    elif isinstance(from_context, OneLakeItem) and isinstance(to_context, OneLakeItem):
        _copy_onelake_2_onelake(from_context, to_context, args)

    # Local to OneLake
    elif isinstance(from_context, LocalPath) and isinstance(to_context, OneLakeItem):
        _copy_local_2_onelake(from_context, to_context, args)

    # OneLake to Local
    elif isinstance(from_context, OneLakeItem) and isinstance(to_context, LocalPath):
        _copy_onelake_2_local(from_context, to_context, args)

    # Source and target items must be same types
    elif from_context.get_type() != to_context.get_type():
        raise FabricCLIError(
            fab_constant.WARNING_INVALID_PATHS, fab_constant.ERROR_INVALID_INPUT
        )

    else:
        raise FabricCLIError(
            fab_constant.WARNING_INVALID_PATHS, fab_constant.ERROR_NOT_SUPPORTED
        )


# OneLake - Files and Folders
def _copy_onelake_2_onelake(
    from_context: OneLakeItem, to_context: OneLakeItem, args: Namespace
) -> None:
    cp_utils.check_onelake_destination(to_context)

    match from_context.get_nested_type():
        case OneLakeItemType.FILE:
            to_context = cp_utils.get_onelake_file_destination(
                to_context, from_context.get_name()
            )

            from_path_id, from_path_name, to_path_id, to_path_name = (
                utils.obtain_id_names_for_onelake(from_context, to_context)
            )
            args.from_path, args.to_path = from_path_id, to_path_id

            utils_ui.print_grey(f"Copying '{from_path_name}' → '{to_path_name}'...")
            content = cp_utils.get_file_content_onelake(args)
            if not content:
                raise FabricCLIError(
                    "Invalid copy, source is empty", fab_constant.ERROR_INVALID_INPUT
                )

            cp_utils.upload_file_onelake(args, content)

        case OneLakeItemType.FOLDER | OneLakeItemType.SHORTCUT | OneLakeItemType.TABLE:
            raise FabricCLIError(
                "Recursive copy not supported", fab_constant.ERROR_NOT_SUPPORTED
            )


# Local to OneLake - Files and Folders


def _copy_local_2_onelake(
    from_context: LocalPath, to_context: OneLakeItem, args: Namespace
) -> None:
    cp_utils.check_onelake_destination(to_context)

    # Unsupported copy operations
    if from_context.is_directory():
        raise FabricCLIError(
            "Recursive copy not supported", fab_constant.ERROR_NOT_SUPPORTED
        )

    # Check if the source is a file
    if not from_context.is_file():
        raise FabricCLIError(
            "Invalid source, expected file",
            fab_constant.ERROR_INVALID_PATH,
        )

    to_context = cp_utils.get_onelake_file_destination(
        to_context, from_context.get_name()
    )

    args.to_path = to_context.get_path_id()

    utils_ui.print_grey(
        f"Copying '{from_context.get_path()}' → '{to_context.get_path()}'..."
    )

    # Read the contents of the local file using the file path property
    try:
        with open(from_context.get_path(), "rb") as file:
            content = file.read()
            if not content:
                raise FabricCLIError(
                    "Invalid copy, source is empty", fab_constant.ERROR_INVALID_INPUT
                )

            cp_utils.upload_file_onelake(args, content)
    except Exception as e:
        if not isinstance(e, FabricCLIError):
            raise FabricCLIError(
                f"Error reading file: {e}", fab_constant.ERROR_INVALID_PATH
            )
        raise e


# OneLake to Local - Files and Folders
def _copy_onelake_2_local(
    from_context: OneLakeItem, to_context: LocalPath, args: Namespace
) -> None:
    match from_context.get_nested_type():
        case OneLakeItemType.FILE:
            # If the destination is a folder, update the context to a new file inside the folder with the same name as the source
            if to_context.is_directory():
                to_context = LocalPath(
                    id=None,
                    name=None,
                    path=os.path.join(to_context.get_path(), from_context.get_name()),
                )

            args.from_path = from_context.get_path_id()
            utils_ui.print_grey(
                f"Copying '{from_context.get_path()}' → '{to_context.get_path()}'..."
            )
            content = cp_utils.get_file_content_onelake(args)
            if not content:
                raise FabricCLIError(
                    "Invalid copy, source is empty", fab_constant.ERROR_INVALID_INPUT
                )

            # Write the contents to a local file using the file path property
            try:
                with open(to_context.get_path(), "wb") as file:
                    file.write(content.encode("utf-8"))
            except Exception as e:
                raise FabricCLIError(
                    f"Error writing file: {e}", fab_constant.ERROR_INVALID_PATH
                )

            utils_ui.print_done("Done")

        case OneLakeItemType.FOLDER | OneLakeItemType.SHORTCUT | OneLakeItemType.TABLE:
            raise FabricCLIError(
                "Recursive copy not supported", fab_constant.ERROR_NOT_SUPPORTED
            )
