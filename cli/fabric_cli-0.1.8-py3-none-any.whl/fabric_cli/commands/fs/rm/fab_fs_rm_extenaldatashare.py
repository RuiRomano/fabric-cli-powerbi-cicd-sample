from argparse import Namespace

from fabric_cli.client import fab_api_item as item_api
from fabric_cli.core.fab_hiearchy import VirtualItem
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_util as utils


def exec(
    virtual_item: VirtualItem, args: Namespace, force_delete: bool
) -> None:
    args.ws_id = virtual_item.get_workspace_id()
    args.id = virtual_item.get_id()
    args.name = virtual_item.get_name()

    item_name = utils.get_item_name_from_eds_name(virtual_item.get_name())
    args.item_id = utils_mem_store.get_item_id(
        virtual_item.get_workspace(), item_name
    )

    if item_api.revoke_item_external_data_share(args, force_delete):
        # Remove from mem_store
        utils_mem_store.delete_external_data_share_from_cache(virtual_item)
