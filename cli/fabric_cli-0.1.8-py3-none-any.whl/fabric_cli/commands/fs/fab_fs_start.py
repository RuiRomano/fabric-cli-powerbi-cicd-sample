import json
from argparse import Namespace

from fabric_cli.client import fab_api_capacity as capacity_api
from fabric_cli.client import fab_api_mirroring as mirroring_api
from fabric_cli.commands.fs import fab_fs as fs
from fabric_cli.core import fab_constant
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import FabricElement, Item, VirtualWorkspaceItem
from fabric_cli.core.fab_types import ItemType, VirtualWorkspaceItemType
from fabric_cli.utils import fab_mem_store as utils_mem_store


def exec_command(args: Namespace, context: FabricElement) -> None:
    force_start = bool(args.force)
    if isinstance(context, VirtualWorkspaceItem):
        _start_virtual_ws_item(context, args, force_start)
    elif isinstance(context, Item):
        _start_item(context, args, force_start)


# Virtual Workspace Items
def _start_virtual_ws_item(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, force_start: bool
) -> None:
    if virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.CAPACITY:
        _start_capacity(virtual_ws_item, args, force_start)


# Virtual Workspace Items - Capacity
def _start_capacity(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, force_start: bool
) -> None:
    fs.fill_capacity_args(virtual_ws_item, args)

    # Only start if the capacity is in an acceptable state
    response = capacity_api.get_capacity(args)
    if response.status_code == 200:
        state = json.loads(response.text)["properties"]["state"]
        if state not in ("Paused", "Suspended"):
            raise FabricCLIError(
                f"'{args.name}' is not in a valid state to start. State: {state}",
                fab_constant.ERROR_ALREADY_RUNNING,
            )

    if capacity_api.resume_capacity(args, force_start):
        utils_mem_store.delete_capacity_from_cache(virtual_ws_item)


# Items - Mirrored Database
def _start_item(item: Item, args: Namespace, force_start: bool) -> None:
    args.ws_id = item.get_workspace_id()
    args.id = item.get_id()
    args.name = item.get_name()

    # Only start if DB stopped
    # status: Initialized, Initializing, Running, Starting, Stopped, Stopping

    response = mirroring_api.get_mirroring_status(args)
    if response.status_code == 200:
        state = json.loads(response.text)["status"]
        if state not in ("Stopped", "Initialized"):
            raise FabricCLIError(
                f"'{args.name}' is not in a valid state to start. State: {state}",
                fab_constant.ERROR_ALREADY_RUNNING,
            )

    if item.get_item_type() == ItemType.MIRRORED_DATABASE:
        mirroring_api.start_mirroring(args, force_start)
