import os
from argparse import Namespace
from typing import Optional

from fabric_cli.client import fab_api_item as item_api
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_commands import Command
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import FabricElement, Item, Workspace
from fabric_cli.core.fab_types import ItemType, definition_format_mapping
from fabric_cli.utils import fab_cmd_export_utils as utils_export
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_storage as utils_storage
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils


# Workspace Items (not workspace itself, multi-item selection)
def export_bulk_items(workspace: Workspace, args: Namespace) -> None:
    ws_items = utils_mem_store.get_workspace_items(workspace)

    if not ws_items:
        fab_logger.log_warning("Your workspace is empty", args.command_path)
        return

    supported_items = []
    for item in ws_items:
        try:
            if item.check_command_support(Command.FS_EXPORT):
                supported_items.append(item)
        except Exception as e:
            pass

    if not supported_items:
        raise FabricCLIError(
            "Export not possible. Existing items cannot be imported/exported",
            fab_constant.ERROR_NOT_SUPPORTED,
        )

    # Add path validation before item selection
    export_path = utils_storage.get_export_path(args.output)

    # Sort output by config
    sorted_supported_items = utils.sort_items_by_config(supported_items)

    if args.all:
        selected_items = [item.get_name() for item in sorted_supported_items]
    else:
        selected_items = utils_ui.prompt_select_items(
            "Select items:",
            [item.get_name() for item in sorted_supported_items],
        )

    if selected_items:
        utils_ui.print_grey("\n".join(selected_items))
        utils_ui.print_grey("------------------------------")
        filtered_items = [
            item for item in supported_items if item.get_name() in selected_items
        ]

        if args.force or utils_ui.prompt_confirm():
            successful_exports = 0

            for item in filtered_items:
                args.force = True  # Already confirmed for workspace
                if export_single_item(item, args):
                    successful_exports = successful_exports + 1
            utils_ui.print("")
            utils_ui.print_done(
                f"{successful_exports} items exported successfully")


# Items
def export_single_item(
    item: Item,
    args: Namespace,
    do_export: Optional[bool] = True,
    decode: Optional[bool] = True,
    item_uri: Optional[bool] = False,
) -> dict:
    item_def = {}

    if args.force or utils_ui.prompt_confirm():
        workspace_id = item.get_workspace_id()
        item_id = item.get_id()
        item_type = item.get_item_type()

        args.from_path = item.get_path().strip("/")
        args.ws_id, args.id, args.item_type = workspace_id, item_id, str(
            item_type)
        args.format = definition_format_mapping.get(item_type, "")

        item_def = item_api.get_item_withdefinition(args, item_uri)

        if decode:
            item_def = utils_export.decode_payload(item_def)
            if item.get_item_type() == ItemType.NOTEBOOK:
                tags_to_clean = ["outputs"]
                item_def = utils_export.clean_notebook_cells(
                    item_def, tags_to_clean)

        if do_export:
            export_path = utils_storage.get_export_path(args.output)

            original_path = export_path["path"]
            export_path["path"] = f"{original_path}/{item.get_name()}"
            _to_path = export_path["path"]

            if export_path["type"] == "local":
                os.makedirs(_to_path, exist_ok=True)
            utils_ui.print_grey(
                f"Exporting '{args.from_path}' → '{_to_path}'...")
            utils_export.export_json_parts(item_def["definition"], export_path)
            utils_ui.print_done(f"'{item.get_full_name()}' exported")

    return item_def
