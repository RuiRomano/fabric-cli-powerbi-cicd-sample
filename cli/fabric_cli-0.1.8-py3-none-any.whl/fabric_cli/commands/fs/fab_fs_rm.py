import os
from argparse import Namespace
from typing import Optional

from fabric_cli.client import fab_api_capacity as capacity_api
from fabric_cli.client import fab_api_connection as connection_api
from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_gateway as gateway_api
from fabric_cli.client import fab_api_item as item_api
from fabric_cli.client import fab_api_managedidentity as managed_identity_api
from fabric_cli.client import (
    fab_api_managedprivateendpoint as managed_private_endpoint_api,
)
from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.client import fab_api_shortcuts as shortcut_api
from fabric_cli.client import fab_api_sparkpool as sparkpool_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.commands.fs import fab_fs as fs
from fabric_cli.commands.fs import fab_fs_cd as fs_cd
from fabric_cli.core import fab_constant, fab_logger
from fabric_cli.core.fab_commands import Command
from fabric_cli.core.fab_context import Context
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    OneLakeItem,
    Tenant,
    VirtualItem,
    VirtualWorkspaceItem,
    Workspace,
)
from fabric_cli.core.fab_types import (
    OneLakeItemType,
    VirtualItemType,
    VirtualWorkspaceItemType,
)
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils


def exec_command(args: Namespace, context: FabricElement) -> None:
    force_delete = bool(args.force)

    if isinstance(context, Tenant):
        _rm_workspaces(context, args, force_delete)
    if isinstance(context, Workspace):
        _rm_workspace(context, args, force_delete)
    elif isinstance(context, Item):
        _rm_item(context, args, force_delete)
    elif isinstance(context, VirtualItem):
        _rm_virtual_item(context, args, force_delete)
    elif isinstance(context, VirtualWorkspaceItem):
        _rm_virtual_ws_item(context, args, force_delete)
    elif isinstance(context, OneLakeItem):
        _rm_onelake(context, args, force_delete)

    if not isinstance(context, Tenant) and Context().get_context().is_ascendent(
        context
    ):
        fs_cd.exec_command(args, context.get_parent())


def _rm_workspaces(tenant: Tenant, args: Namespace, force_delete: bool) -> None:
    workspaces: list[Workspace] = utils_mem_store.get_workspaces(tenant)
    sorted_workspaces: list[Workspace] = sorted(
        workspaces, key=lambda ws: ws.get_name()
    )

    names = [workspace.get_name() for workspace in sorted_workspaces]
    selected_workspaces = utils_ui.prompt_select_items("Select workspaces:", names)
    if selected_workspaces:
        for workspace_str in selected_workspaces:
            utils_ui.print_grey(workspace_str)
        utils_ui.print_grey("------------------------------")
        filtered_workspaces = [
            workspace
            for workspace in sorted_workspaces
            if workspace.get_name() in selected_workspaces
        ]
        if utils_ui.prompt_confirm():

            deleted_workspaces = 0

            for workspace in filtered_workspaces:
                args.ws_id = workspace.get_id()
                args.name = workspace.get_name()

                # Reset args for subsequent calls
                args.uri = None
                args.method = None

                if workspace_api.delete_workspace(args, bypass_confirmation=True):
                    deleted_workspaces = deleted_workspaces + 1

                    # Remove from mem_store
                    utils_mem_store.delete_workspace_from_cache(workspace)

            utils_ui.print("")
            utils_ui.print_done(f"{deleted_workspaces} workspaces deleted successfully")


# Single Workspace (-f) workspace items
def _rm_workspace(workspace: Workspace, args: Namespace, force_delete: bool) -> None:
    args.ws_id = workspace.get_id()
    args.name = workspace.get_name()

    ws_items: list[Item] = utils_mem_store.get_workspace_items(workspace)

    # Empty workspace
    if not ws_items and not force_delete:
        raise FabricCLIError(
            "Empty workspace. Use -f to remove it",
            fab_constant.ERROR_NOT_SUPPORTED,
        )

    # Filter items supporting rm
    supported_items = []
    for item in ws_items:
        try:
            if item.check_command_support(Command.FS_RM):
                supported_items.append(item)
        except Exception as e:
            pass

    if force_delete:
        utils_ui.print_grey(f"This will delete {len(ws_items)} underlying items")

        if workspace_api.delete_workspace(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_workspace_from_cache(workspace)
    else:
        # Some items don't support delete
        if not supported_items:
            raise FabricCLIError(
                "Items can't be deleted. Use -f to remove the workspace",
                fab_constant.ERROR_NOT_SUPPORTED,
            )
        else:
            # Sort output by config
            sorted_items = utils.sort_items_by_config(supported_items)

            names = [item.get_name() for item in sorted_items]
            selected_items = utils_ui.prompt_select_items("Select items:", names)
            if selected_items:
                for item_str in selected_items:
                    utils_ui.print_grey(item_str)
                utils_ui.print_grey("------------------------------")
                filtered_items = [
                    item for item in sorted_items if item.get_name() in selected_items
                ]
                if utils_ui.prompt_confirm():

                    deleted_items = 0

                    for item in filtered_items:
                        args.id = item.get_id()
                        args.name = item.get_name()
                        args.item_type = str(item.get_type())

                        # Reset args for subsequent calls
                        args.uri = None
                        args.method = None

                        if item_api.delete_item(
                            args, bypass_confirmation=True, debug=False
                        ):
                            utils_ui.print_done(f"'{args.name}' deleted")
                            deleted_items = deleted_items + 1

                            # Remove from mem_store
                            utils_mem_store.delete_item_from_cache(item)

                    utils_ui.print("")
                    utils_ui.print_done(f"{deleted_items} items deleted successfully")


# Items
def _rm_item(item: Item, args: Namespace, force_delete: bool) -> None:
    args.ws_id = item.get_workspace_id()
    args.id = item.get_id()
    args.name = item.get_name()
    args.item_type = item.get_type().value

    if item_api.delete_item(args, force_delete):
        # Remove from mem_store
        utils_mem_store.delete_item_from_cache(item)


# Virtual Item
def _rm_virtual_item(
    virtual_item: VirtualItem, args: Namespace, force_delete: bool
) -> None:
    if virtual_item.get_item_type() == VirtualItemType.SPARK_POOL:
        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        if sparkpool_api.delete_spark_pool(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_spark_pool_from_cache(virtual_item)
        return

    if virtual_item.get_item_type() == VirtualItemType.MANAGED_IDENTITY:
        if (
            virtual_item.get_short_name()
            != virtual_item.get_workspace().get_short_name()
        ):
            fab_logger.log_warning(
                "A valid ManagedIdentity matching the Workspace name must be provided"
            )
            return

        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        if managed_identity_api.deprovision_managed_identity(args, force_delete):
            utils_mem_store.delete_managed_identity_from_cache(virtual_item)
        return

    if virtual_item.get_item_type() == VirtualItemType.MANAGED_PRIVATE_ENDPOINT:
        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        if managed_private_endpoint_api.delete_managed_private_endpoint(
            args, force_delete
        ):
            # Remove from mem_store
            utils_mem_store.delete_managed_private_endpoint_from_cache(virtual_item)
        return

    if virtual_item.get_item_type() == VirtualItemType.EXTERNAL_DATA_SHARE:
        args.ws_id = virtual_item.get_workspace_id()
        args.id = virtual_item.get_id()
        args.name = virtual_item.get_name()

        item_name = utils.get_item_name_from_eds_name(virtual_item.get_name())
        args.item_id = utils_mem_store.get_item_id(
            virtual_item.get_workspace(), item_name
        )

        if item_api.revoke_item_external_data_share(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_external_data_share_from_cache(virtual_item)
        return

    fab_logger.log_warning("Deletion is not supported", args.command_path)


# Virtual Workspace Item
def _rm_virtual_ws_item(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, force_delete: bool
) -> None:
    if virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.CAPACITY:
        fs.fill_capacity_args(virtual_ws_item, args)

        if capacity_api.delete_capacity(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_capacity_from_cache(virtual_ws_item)

    elif virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.CONNECTION:
        args.id = virtual_ws_item.get_id()
        args.name = virtual_ws_item.get_name()
        if connection_api.delete_connection(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_connection_from_cache(virtual_ws_item)

    elif virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.GATEWAY:
        args.id = virtual_ws_item.get_id()
        args.name = virtual_ws_item.get_name()
        if gateway_api.delete_gateway(args, force_delete):
            # Remove from mem_store
            utils_mem_store.delete_gateway_from_cache(virtual_ws_item)

    elif virtual_ws_item.get_item_type() == VirtualWorkspaceItemType.DOMAIN:
        _rm_domain(virtual_ws_item, args, force_delete)
        return

    else:
        fab_logger.log_warning("Deletion is not supported", args.command_path)


def _rm_domain(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace, force_delete: bool
) -> None:
    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    args.id = virtual_ws_item.get_id()
    args.name = virtual_ws_item.get_name()
    if domain_api.delete_domain(args, force_delete):
        # Remove from mem_store
        utils_mem_store.delete_domain_from_cache(virtual_ws_item)
    return


# OneLake - Shortcut, File and Folder
def _rm_onelake(
    onelake: OneLakeItem,
    args: Namespace,
    force_delete: bool,
    debug: Optional[bool] = True,
) -> None:
    # Remove shortcut
    if onelake.get_nested_type() == OneLakeItemType.SHORTCUT:
        args.ws_id = onelake.get_workspace_id()
        args.id = onelake.get_item_id()
        args.path, args.sc_name = os.path.split(onelake.get_local_path().rstrip("/"))
        args.name = onelake.get_full_name()  # the name that is displayed in the UI

        shortcut_api.delete_shortcut(args, force_delete, debug)
        return

    # Remove file or folder
    path_name = utils.process_nargs(args.path)
    path_id = onelake.get_path_id().strip("/")

    args.directory = path_id
    args.name = path_name

    onelake_api.delete_dir(args, force_delete, debug)
