import json
import re
import time
from argparse import Namespace
from collections.abc import MutableMapping
from typing import Any, Dict

from fabric_cli.client import fab_api_capacity as capacity_api
from fabric_cli.client import fab_api_connection as connection_api
from fabric_cli.client import fab_api_domain as domain_api
from fabric_cli.client import fab_api_gateway as gateway_api
from fabric_cli.client import fab_api_item as item_api
from fabric_cli.client import fab_api_managedidentity as managed_identity_api
from fabric_cli.client import (
    fab_api_managedprivateendpoint as managed_private_endpoint_api,
)
from fabric_cli.client import fab_api_onelake as onelake_api
from fabric_cli.client import fab_api_sparkpool as sparkpool_api
from fabric_cli.client import fab_api_workspace as workspace_api
from fabric_cli.core import fab_constant, fab_logger, fab_state_config
from fabric_cli.core.fab_exceptions import FabricCLIError
from fabric_cli.core.fab_hiearchy import (
    FabricElement,
    Item,
    OneLakeItem,
    VirtualItem,
    VirtualWorkspaceItem,
    Workspace,
)
from fabric_cli.core.fab_types import (
    ItemOnelakeWritableFoldersMap,
    ItemType,
    VirtualItemType,
    VirtualWorkspaceItemType,
    format_mapping,
)
from fabric_cli.utils import fab_cmd_mkdir_utils as mkdir_utils
from fabric_cli.utils import fab_handle_context as handle_context
from fabric_cli.utils import fab_mem_store as utils_mem_store
from fabric_cli.utils import fab_ui as utils_ui
from fabric_cli.utils import fab_util as utils


def exec_command(args: Namespace, context: FabricElement) -> None:
    if (
        isinstance(context, VirtualItem)
        and context.get_item_type() == VirtualItemType.SPARK_POOL
    ):
        args.params = utils.get_dict_from_params(args.params, max_depth=1)
    elif (
        isinstance(context, VirtualWorkspaceItem)
        and context.get_item_type() == VirtualWorkspaceItemType.CONNECTION
    ):
        # Example: -P connectionDetails.parameters.server=serverName
        args.params = utils.get_dict_from_params(args.params, max_depth=3)
    else:
        args.params = utils.get_dict_from_params(args.params)

    # Lowercase params
    args.params = mkdir_utils.lowercase_keys(args.params)

    if isinstance(context, Workspace):
        _mkdir_workspace(context, args)
    elif isinstance(context, Item):
        _mkdir_item(context, args)
    elif isinstance(context, VirtualItem):
        _mkdir_virtual_item(context, args)
    elif isinstance(context, VirtualWorkspaceItem):
        _mkdir_virtual_ws_item(context, args)
    elif isinstance(context, OneLakeItem):
        _mkdir_onelake_directory(context, args)


# Workspaces
def _mkdir_workspace(workspace: Workspace, args: Namespace) -> None:
    # Params
    optional_params = ["capacityName"]
    if mkdir_utils.show_params_desc(
        args.params, workspace.get_ws_type(), optional_params=optional_params
    ):
        return

    if workspace.get_id() is not None:
        raise FabricCLIError(
            "A workspace with the same name exists", fab_constant.ERROR_ALREADY_EXISTS
        )

    default_capacity_id = fab_state_config.get_config(
        fab_constant.FAB_DEFAULT_CAPACITY_ID
    )

    params = args.params
    _capacity_name = params.get("capacityname", "")

    if _capacity_name:
        if _capacity_name != fab_constant.FAB_CAPACITY_NAME_NONE:
            # In case .Capacity is provided, remove it
            _capacity_name = utils.remove_dot_suffix(_capacity_name, ".Capacity")
            capacity = handle_context.get_command_context(
                f"/.capacities/{_capacity_name}.Capacity"
            )
            params["capacityId"] = capacity.get_id()

        # Remove the capacityName from the params so it doesn't get sent to the API
        key_to_remove = next(
            (k for k in params.keys() if k.lower() == "capacityname"), None
        )
        if key_to_remove:
            params.pop(key_to_remove)
    else:
        params["capacityId"] = default_capacity_id

    if "capacityId" in params and not params.get("capacityId"):
        raise FabricCLIError(
            f"Capacity not found or invalid. "
            f"Use 'config set default_capacity <capacity_name>' or '-P capacityName=<capacity_name>'",
            fab_constant.ERROR_INVALID_INPUT,
        )

    utils_ui.print_grey("Creating a new Workspace...")

    # Remove all unwanted keys from the params
    utils.remove_keys_from_dict(args.params, ["displayName"])

    payload = {
        "description": "Created by fab",
        "displayName": workspace.get_short_name(),
    }
    payload.update(args.params)
    json_payload = json.dumps(payload)

    response = workspace_api.create_workspace(args, json_payload)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{workspace.get_name()}' created")
        data = json.loads(response.text)
        workspace._id = data["id"]

        # Add to mem_store
        utils_mem_store.upsert_workspace_to_cache(workspace)


# Virtual Workspace Items
def _mkdir_virtual_ws_item(
    virtual_ws_item: VirtualWorkspaceItem, args: Namespace
) -> None:
    if virtual_ws_item.get_id() is not None:
        raise FabricCLIError(
            "An element with the same name exists", fab_constant.ERROR_ALREADY_EXISTS
        )

    match virtual_ws_item.get_item_type():
        case VirtualWorkspaceItemType.CAPACITY:
            _mkdir_capacity(virtual_ws_item, args)
        case VirtualWorkspaceItemType.DOMAIN:
            _mkdir_domain(virtual_ws_item, args)
        case VirtualWorkspaceItemType.CONNECTION:
            _mkdir_connection(virtual_ws_item, args)
        case VirtualWorkspaceItemType.GATEWAY:
            _mkdir_gateway(virtual_ws_item, args)
        case _ as x:
            raise FabricCLIError(
                f"{str(x)} not supported", fab_constant.ERROR_NOT_SUPPORTED
            )


# Virtual Workspace Items - Capacity
def _mkdir_capacity(capacity: VirtualWorkspaceItem, args: Namespace) -> None:
    # Params
    optional_params = ["subscriptionId", "resourceGroup", "location", "admin", "sku"]
    if mkdir_utils.show_params_desc(
        args.params, capacity.get_item_type(), optional_params=optional_params
    ):
        return

    (
        az_default_admin,
        az_default_location,
        az_subscription_id,
        az_resource_group,
        _sku,
    ) = utils.get_capacity_settings(args.params)

    utils_ui.print_grey(f"Creating a new Capacity...")

    payload: MutableMapping = {
        "properties": {
            "administration": {
                "members": [
                    f"{az_default_admin}",
                ]
            }
        },
        "sku": {"name": "F2", "tier": "Fabric"},
        "location": f"{az_default_location}",
    }

    args.subscription_id = az_subscription_id
    args.resource_group_name = az_resource_group
    args.name = capacity.get_short_name()
    payload["sku"]["name"] = _sku

    if not (3 <= len(args.name) <= 63):
        raise FabricCLIError(
            "Name must be between 3 and 63 characters in length",
            fab_constant.ERROR_INVALID_INPUT,
        )

    pattern = r"^[a-z][a-z0-9]*$"
    if not re.match(pattern, args.name):
        raise FabricCLIError(
            "Name must start with a lowercase letter and contain only lowercase letters or digits",
            fab_constant.ERROR_INVALID_INPUT,
        )

    # Remove all unwanted keys from the params
    utils.remove_keys_from_dict(args.params, ["properties", "run"])
    # if args.params.get("sku"):
    #     if not args.params.get("sku").get("tier"):
    #         args.params["sku"]["tier"] = "Fabric"

    # payload.update(args.params)

    # if args.params.get("sku"):
    #     _sku: str = str(args.params.get("sku"))
    #     payload["sku"]["name"] = _sku

    json_payload = json.dumps(payload)

    response = capacity_api.create_capacity(args, payload=json_payload)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{capacity.get_name()}' created")
        # data = json.loads(response.text)
        # In here we use a different approach since the id responded by the API is not the same as the id we use in the code
        # The id in the response is the fully qualified azure resource ID for the resource
        # The id in Fabric is the giud of the resource
        # Calling the mem_store method to get the capacity id from the name invalids the cache and performs and API call to the Fabric endpoint to get the GIUD
        try:
            capacity._id = utils_mem_store.get_capacity_id(
                capacity.get_tenant(), capacity.get_name()
            )
            utils_mem_store.upsert_capacity_to_cache(capacity)
        except FabricCLIError as e:
            # If the capacity is not found, it means the user is not an admin of the capacity
            if e.status_code == "NotFound":
                utils_ui.print_warning(
                    "You are not listed as and administrator of the capacity. You won't be able to see or manage it."
                )
            else:
                raise e


# Virtual Workspace Items - Connection
def _mkdir_connection(connection: VirtualWorkspaceItem, args: Namespace) -> None:
    # Params
    required_params = [
        "connectionDetails.type",
        "connectionDetails.parameters.*",
        "credentialDetails.type",
        "credentialDetails.*",
    ]
    optional_params = [
        "gateway|gatewayId",
        "privacyLevel",
        "description",
        "connectionDetails.creationMethod",
        "credentialDetails.singleSignOnType",
        "credentialDetails.connectionEncryption",
        "credentialDetails.skipTestConnection",
    ]

    if mkdir_utils.show_params_desc(
        args.params,
        connection.get_item_type(),
        required_params=required_params,
        optional_params=optional_params,
    ):
        return

    # Lowercase params
    params = args.params

    if params.get("gateway"):
        # Get the gateway id from the gateway name
        gateway_name = params.get("gateway")
        if not gateway_name.endswith(".Gateway"):
            gateway_name = f"{gateway_name}.Gateway"
        gateway = handle_context.get_command_context(f"/.gateways/{gateway_name}")
        params["gatewayid"] = gateway.get_id()

    if params.get("gatewayid"):
        gateway_id = params.get("gatewayid")
        args.id = gateway_id
        response = gateway_api.get_gateway(args)
        if response.status_code != 200:
            raise FabricCLIError(
                f"Gateway with id {gateway_id} not found",
                fab_constant.ERROR_NOT_FOUND,
            )
        body = json.loads(response.text)
        match body.get("type"):
            case "OnPremisesGateway" | "OnPremisesGatewayPersonal":
                connectivityType = "OnPremisesGateway"
            case "VirtualNetwork":
                connectivityType = "VirtualNetworkGateway"
            case _ as x:
                raise FabricCLIError(
                    f"Gateway type {x} not supported", fab_constant.ERROR_NOT_SUPPORTED
                )
    else:
        gateway_id = None
        connectivityType = "ShareableCloud"

    if gateway_id:
        # Modify params to obtain the gatewayId
        args.request_params = {"gatewayId": gateway_id}

    response = connection_api.list_supported_connection_types(args)
    if response.status_code != 200:
        raise FabricCLIError(
            "Failed to list supported connection types",
            fab_constant.ERROR_NOT_SUPPORTED,
        )
    args.request_params = {}

    supp_con_types = json.loads(response.text)["value"]
    con_type = params.get("connectiondetails", {}).get("type")
    if con_type is None:
        supp_con_types_str = ", ".join([x["type"] for x in supp_con_types])
        raise FabricCLIError(
            f"Connection type is required. Available connection types are: {supp_con_types_str}",
            fab_constant.ERROR_INVALID_INPUT,
        )

    con_type_def = next(
        (item for item in supp_con_types if item["type"].lower() == con_type.lower()),
        None,
    )

    if con_type_def is None:
        raise FabricCLIError(
            f"Connection type '{con_type}' not found", fab_constant.ERROR_INVALID_INPUT
        )

    utils_ui.print_grey(f"Creating a new Connection...")

    # Base payload
    payload = {
        "description": "Created by fab",
        "displayName": connection.get_short_name(),
        "connectivityType": connectivityType,
    }
    if gateway_id:
        payload["gatewayId"] = gateway_id

    payload = mkdir_utils.get_connection_config_from_params(
        payload, con_type, con_type_def, args.params
    )

    json_payload = json.dumps(payload)

    response = connection_api.create_connection(args, payload=json_payload)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{connection.get_name()}' created")
        data = json.loads(response.text)
        connection._id = data["id"]

        # Add to mem_store
        utils_mem_store.upsert_connection_to_cache(connection)


# Virtual Workspace Items - Domain
def _mkdir_domain(domain: VirtualWorkspaceItem, args: Namespace) -> None:
    optional_params = ["description", "parentDomainName"]
    if mkdir_utils.show_params_desc(
        args.params, domain.get_item_type(), optional_params=optional_params
    ):
        return

    fab_logger.log_warning(fab_constant.WARNING_FABRIC_ADMIN_ROLE)
    utils_ui.print_grey(f"Creating a new Domain...")

    payload = {"displayName": f"{domain.get_short_name()}"}
    optional_payload = {}

    params = args.params

    for key in optional_params:
        lowercase_key = key.lower()
        if params.get(lowercase_key):
            # Convert name to id
            if lowercase_key == "parentdomainname":
                domain_name = params[lowercase_key]
                domain_name = domain_name.removesuffix(".domain").removesuffix(
                    ".Domain"
                )
                domain_name += ".Domain"

                value = utils_mem_store.get_domain_id(domain.get_tenant(), domain_name)
                optional_payload["parentDomainId"] = value
            else:
                value = params[lowercase_key]
                optional_payload[lowercase_key] = value

    payload.update(optional_payload)
    json_payload = json.dumps(payload)

    response = domain_api.create_domain(args, payload=json_payload)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{domain.get_name()}' created")
        data = json.loads(response.text)

        domain._id = data["id"]

        # Add to mem_store
        utils_mem_store.upsert_domain_to_cache(domain)


# Virtual Workspace Items - Gateway
def _mkdir_gateway(gateway: VirtualWorkspaceItem, args: Namespace) -> None:
    # Params
    required_params = [
        "capacity|capacityId",
        "virtualNetworkName",
        "subnetName",
    ]
    optional_params = [
        "inactivityMinutesBeforeSleep",  # Default: 30
        "numberOfMemberGateways",  # Default: 1
        "subscriptionId",
        "resourceGroupName",
    ]

    if mkdir_utils.show_params_desc(
        args.params,
        gateway.get_item_type(),
        required_params=required_params,
        optional_params=optional_params,
    ):
        return

    utils_ui.print_grey(f"Creating a new Gateway...")

    # Lowercase params
    params = args.params

    if params.get("capacity"):
        # Get the capacity id from the capacity name
        capacity_name = params.get("capacity")
        if not capacity_name.endswith(".Capacity"):
            capacity_name = f"{capacity_name}.Capacity"
        capacity = handle_context.get_command_context(f"/.capacities/{capacity_name}")
        params["capacityid"] = capacity.get_id()

    if not params.get("capacityid"):
        raise FabricCLIError(
            "Capacity Name or ID is required", fab_constant.ERROR_INVALID_INPUT
        )

    if not params.get("virtualnetworkname") or not params.get("subnetname"):
        raise FabricCLIError(
            "Virtual Network and Subnet Name is required",
            fab_constant.ERROR_INVALID_INPUT,
        )

    if not params.get("subscriptionid"):
        vnet = params.get("virtualnetworkname")
        subnet = params.get("subnetname")
        sub_id, rg_name = mkdir_utils.find_vnet_subnet(vnet, subnet)
        utils_ui.print_grey(
            f"Found Subnet '{vnet}/{subnet}' in Subscription '{sub_id}' and Resource Group '{rg_name}'"
        )
        params["subscriptionid"] = sub_id
        params["resourcegroupname"] = rg_name

    if not params.get("subscriptionid") or not params.get("resourcegroupname"):
        raise FabricCLIError(
            "Subscription ID and Resource Group Name is required",
            fab_constant.ERROR_INVALID_INPUT,
        )

    vnet_res = {
        "subscriptionId": params.get("subscriptionid"),
        "resourceGroupName": params.get("resourcegroupname"),
        "virtualNetworkName": params.get("virtualnetworkname"),
        "subnetName": params.get("subnetname"),
    }

    payload = {
        # "description": "Created by fab",
        "displayName": gateway.get_short_name(),
        "capacityId": params.get("capacityid"),
        "inactivityMinutesBeforeSleep": params.get("inactivityminutesbeforesleep", 30),
        "numberOfMemberGateways": args.params.get("numberofmembergateways", 1),
        "type": "VirtualNetwork",
        "virtualNetworkAzureResource": vnet_res,
    }

    response = gateway_api.create_gateway(args, payload=json.dumps(payload))
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{gateway.get_name()}' created")
        data = json.loads(response.text)
        gateway._id = data["id"]

        # Add to mem_store
        utils_mem_store.upsert_gateway_to_cache(gateway)


# Items
def _mkdir_item(item: Item, args: Namespace) -> str | None:
    # Params
    params = args.params
    required_params, optional_params = mkdir_utils.get_params_per_item_type(item)

    if mkdir_utils.show_params_desc(
        params,
        item.get_item_type(),
        required_params=required_params,
        optional_params=optional_params,
    ):
        return None

    if item.get_id() is not None:
        raise FabricCLIError(
            "An item with the same name exists", fab_constant.ERROR_ALREADY_EXISTS
        )

    # Check required params
    mkdir_utils.check_required_params(params, required_params)

    args.ws_id = item.get_workspace_id()
    item_name = item.get_short_name()
    item_type = item.get_item_type()

    utils_ui.print_grey(f"Creating a new {item_type}...")
    args.item_type = str(item_type).lower()

    # Remove all unwanted keys from the params
    utils.remove_keys_from_dict(params, ["displayname", "type"])

    payload = {
        "description": "Created by fab",
        "displayName": item_name,
        "type": str(item_type),
    }
    payload = mkdir_utils.add_type_specific_payload(item, args, payload)
    json_payload = json.dumps(payload)
    args.item_uri = format_mapping.get(item.get_item_type(), "items")

    response = item_api.create_item(args, json_payload, item_uri=True)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{item.get_name()}' created")
        data = json.loads(response.text)
        if data is not None and data.get("id"):
            _item_id = data["id"]
            item._id = _item_id
            # Update the cache with the new item
            utils_mem_store.upsert_item_to_cache(item)
            return _item_id
        else:
            # If the response does not contain an id, invalidate the cache
            utils_mem_store.invalidate_item_cache(item.get_workspace())
            return None
    return None


# Virtual Items
def _mkdir_virtual_item(virtual_item: VirtualItem, args: Namespace) -> None:
    if virtual_item.get_id() is not None:
        raise FabricCLIError(
            "An element with the same name exists", fab_constant.ERROR_ALREADY_EXISTS
        )

    match virtual_item.get_item_type():
        case VirtualItemType.SPARK_POOL:
            _mkdir_spark_pool(virtual_item, args)
        case VirtualItemType.MANAGED_IDENTITY:
            _mkdir_managed_identity(virtual_item, args)
        case VirtualItemType.MANAGED_PRIVATE_ENDPOINT:
            _mkdir_managed_private_endpoint(virtual_item, args)
        case VirtualItemType.EXTERNAL_DATA_SHARE:
            _mkdir_external_data_share(virtual_item, args)
        case _ as x:
            raise FabricCLIError(
                f"{str(x)} not supported", fab_constant.ERROR_NOT_SUPPORTED
            )


# Virtual Items - Spark Pool
def _mkdir_spark_pool(spark_pool: VirtualItem, args: Namespace) -> None:
    # Params
    optional_params = [
        "autoScale.maxNodeCount",
        "autoScale.minNodeCount",
        "nodeSize",
    ]
    if mkdir_utils.show_params_desc(
        args.params, spark_pool.get_item_type(), optional_params=optional_params
    ):
        return

    # For autoscale, if only minNodeCount is provided, disable autoscale
    # If maxNodeCount is provided, enable autoscale

    payload: Dict = {
        "name": f"{spark_pool.get_short_name()}",
        "nodeFamily": "MemoryOptimized",
        "nodeSize": "Small",
        "autoScale": {"enabled": True, "minNodeCount": 1, "maxNodeCount": 1},
        "dynamicExecutorAllocation": {
            "enabled": False,
            "minExecutors": 1,
            "maxExecutors": 1,
        },
    }

    # Remove all unwanted keys from the params
    utils.remove_keys_from_dict(args.params, ["displayName"])

    # Lowercase params and validate
    params = args.params
    mkdir_utils.validate_spark_pool_params(params)

    try:
        if params.get("autoscale.minnodecount") or params.get("autoscale.maxnodecount"):
            payload["autoScale"]["enabled"] = False

            if params.get("autoscale.minnodecount"):
                payload["autoScale"]["minNodeCount"] = int(
                    params.get("autoscale.minnodecount")
                )
            else:
                payload["autoScale"]["minNodeCount"] = 1

            if params.get("autoscale.maxnodecount"):
                payload["autoScale"]["enabled"] = True
                payload["autoScale"]["maxNodeCount"] = int(
                    params.get("autoscale.maxnodecount")
                )
            else:
                payload["autoScale"]["maxNodeCount"] = payload["autoScale"][
                    "minNodeCount"
                ]
    except Exception as e:
        raise FabricCLIError(
            f"Invalid parameter values: {e}", fab_constant.ERROR_INVALID_INPUT
        )

    if params.get("nodesize"):
        payload["nodeSize"] = params.get("nodesize").lower()

    json_payload = json.dumps(payload)
    args.ws_id = spark_pool.get_workspace_id()

    utils_ui.print_grey(f"Creating a new Spark Pool...")
    response = sparkpool_api.create_spark_pool(args, payload=json_payload)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{spark_pool.get_name()}' created")
        data = json.loads(response.text)
        spark_pool._id = data["id"]

        # Add to mem_store
        utils_mem_store.upsert_spark_pool_to_cache(spark_pool)


# Virtual Items - Managed Identity
def _mkdir_managed_identity(managed_identity: VirtualItem, args: Namespace) -> None:
    # Params
    if mkdir_utils.show_params_desc(args.params, managed_identity.get_item_type()):
        return

    utils_ui.print_warning(
        "Managed Identity will use the workspace name, provided name is ignored"
    )

    managed_identity._name = managed_identity.get_workspace().get_short_name()
    args.ws_id = managed_identity.get_workspace_id()

    utils_ui.print_grey(f"Creating a new Managed Identity...")
    response = managed_identity_api.provision_managed_identity(args)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{managed_identity.get_name()}' created")
        data = json.loads(response.text)
        managed_identity._id = data["servicePrincipalId"]

        # Add to mem_store
        utils_mem_store.upsert_managed_identity_to_cache(managed_identity)


# Virtual Items - Managed Private Endpoint
def _mkdir_managed_private_endpoint(
    managed_private_endpoint: VirtualItem, args: Namespace
) -> None:
    # Params
    params = args.params
    required_params = ["targetPrivateLinkResourceId", "targetSubresourceType"]
    optional_params = ["autoApproveEnabled"]
    if mkdir_utils.show_params_desc(
        params,
        managed_private_endpoint.get_item_type(),
        required_params=required_params,
        optional_params=optional_params,
    ):
        return

    # Check required
    mkdir_utils.check_required_params(params, required_params)

    payload = {
        "name": f"{managed_private_endpoint.get_short_name()}",
        "targetPrivateLinkResourceId": params.get("targetprivatelinkresourceid"),
        "targetSubresourceType": params.get("targetsubresourcetype"),
        "requestMessage": "Created by fab",
    }

    json_payload = json.dumps(payload)
    args.ws_id = managed_private_endpoint.get_workspace_id()

    utils_ui.print_grey(
        f"Creating a new Managed Private Endpoint. It may take same time (waiting until provisioned)..."
    )
    response = managed_private_endpoint_api.create_managed_private_endpoint(
        args, payload=json_payload
    )
    if response.status_code in (200, 201):
        data = json.loads(response.text)
        managed_private_endpoint._id = data["id"]

        # Add to mem_store
        utils_mem_store.upsert_managed_private_endpoint_to_cache(
            managed_private_endpoint
        )

        # First check the state of the private endpoint
        s_args = Namespace()
        s_args.ws_id = managed_private_endpoint.get_workspace_id()
        s_args.id = managed_private_endpoint.get_id()
        state = "Unknown"
        # List of states: https://learn.microsoft.com/en-us/rest/api/fabric/core/managed-private-endpoints/get-workspace-managed-private-endpoint?tabs=HTTP#privateendpointprovisioningstate
        # Deleting Failed Provisioning Succeeded Updating
        iteration = 0
        while True:
            try:
                response = managed_private_endpoint_api.get_managed_private_endpoint(
                    s_args
                )
                if response.status_code == 200:
                    state = json.loads(response.text)["provisioningState"]
                    # If the state is not Provisioning, stop the loop
                    if state != "Provisioning":
                        break
                    connection = mkdir_utils.find_mpe_connection(
                        managed_private_endpoint,
                        params.get("targetprivatelinkresourceid"),
                    )
                    if connection:
                        # If it is ready from the Azure side, we can consider it
                        state = "Succeeded"
                        break
                    # Wait exponentially
                    time.sleep(2**iteration)
                    iteration += 1
            except Exception:
                state = "Failed"
                break

        if state != "Succeeded":
            raise FabricCLIError(
                f"Managed Private Endpoint was created on Fabric but encountered an issue on Azure provisioning. State: {state}",
                fab_constant.ERROR_OPERATION_FAILED,
            )

        utils_ui.print_done(f"'{managed_private_endpoint.get_name()}' created")

        if params.get("autoapproveenabled", "false").lower() == "true":

            utils_ui.print_grey(f"Approving the Managed Private Endpoint...")

            # Try to approve it
            try:
                connection = mkdir_utils.find_mpe_connection(
                    managed_private_endpoint, params.get("targetprivatelinkresourceid")
                )
                if (
                    connection
                    and connection["properties"]["privateLinkServiceConnectionState"][
                        "status"
                    ]
                    == "Pending"
                ):
                    _args = Namespace()
                    _args.resource_uri = connection["id"]
                    response = managed_private_endpoint_api.approve_private_endpoint_connection(
                        _args
                    )
                    if response.status_code == 200:
                        utils_ui.print_done(
                            f"'{managed_private_endpoint.get_name()}' approved"
                        )
                    else:
                        raise Exception("Approval failed")
            except Exception:
                raise FabricCLIError(
                    f"Approval for Managed Private Endpoint failed",
                    fab_constant.ERROR_OPERATION_FAILED,
                )


# Virtual Items - External Data Share
def _mkdir_external_data_share(
    external_data_share: VirtualItem, args: Namespace
) -> None:
    # Params
    params = args.params
    required_params = [
        "paths",
        "recipient.userPrincipalName",
        "recipient.tenantId",
        "item",
    ]
    if mkdir_utils.show_params_desc(
        params,
        external_data_share.get_item_type(),
        required_params=required_params,
    ):
        return

    # Check required
    mkdir_utils.check_required_params(params, required_params)

    utils_ui.print_warning(
        "External Data Share will use the Item name and the ExternalDataShare id - provided name is ignored"
    )

    utils_ui.print_grey(f"Creating a new External Data Share...")
    item_path = handle_context.get_command_context(params.get("item"))

    raw_paths = params.get("paths")
    cleaned_paths = raw_paths.strip("[]")
    paths = cleaned_paths.split(",")

    payload = {
        "paths": paths,
        "recipient": params.get("recipient"),
    }

    json_payload = json.dumps(payload)
    args.ws_id = external_data_share.get_workspace_id()
    args.item_id = item_path.get_id()

    response = item_api.create_item_external_data_share(args, payload=json_payload)
    if response.status_code in (200, 201):
        data = json.loads(response.text)
        external_data_share._id = data["id"]
        external_data_share._name = utils.get_external_data_share_name(
            item_path.get_name(), external_data_share.get_id()
        )
        utils_ui.print_done(f"'{external_data_share.get_name()}' created")

        # Add to mem_store
        utils_mem_store.upsert_external_data_share_to_cache(
            external_data_share, item_path
        )


# OneLake - Folder
def _mkdir_onelake_directory(onelake: OneLakeItem, args: Namespace) -> None:
    # Params
    if mkdir_utils.show_params_desc(args.params, onelake.get_type()):
        return

    # Supported folders
    item_type: ItemType = onelake.get_item_type()
    root_folder = onelake.get_root_folder()
    supported_folders = ItemOnelakeWritableFoldersMap[item_type]

    if root_folder not in supported_folders:
        raise FabricCLIError(
            f"Cannot create folders under '{root_folder}' for {item_type}. Only {supported_folders} folders are supported",
            fab_constant.ERROR_NOT_SUPPORTED,
        )

    path_name = utils.process_nargs(args.path)  # onelake.get_path().strip("/")
    path_id = onelake.get_path_id().strip("/")

    utils_ui.print_grey(f"Creating a new Directory...")
    args.directory = path_id

    response = onelake_api.create_dir(args)
    if response.status_code in (200, 201):
        utils_ui.print_done(f"'{path_name}' created")
